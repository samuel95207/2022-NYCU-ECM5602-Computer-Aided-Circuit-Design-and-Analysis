# Project1 - Parser & Stamping
## Usage
```
make
cd bin
./Project1 [input] [outputMNA] [outputXVec] [outputRHS]
```